#防止可能因大小写或少个字而产生防不胜防且难以根治以及高深莫测的 bug 而写的 keywords,自动补全就是好用
# buttton keyword
ANTE  = 'ante'
CHECK = 'check'
BET_RAISE = 'bet/raise'
FOLD  = 'fold'
CALL = 'call'
INCREASE = '+'
DECREASE = '-'

USERNAME = 'username'
PASSWORD = 'password'
C_PASSWORD = 'confirm password'
SIGN_IN = 'sign in'
SIGN_UP = 'sign up'

COMBO_RATING = ['high card', 'one pair', 'two pair', 'three of a kind', 'straight', 'flush', 'full house', 'four of a kind', 'straight flush']