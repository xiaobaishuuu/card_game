from init import *

class Holdme:
    """    # only calculates"""

    def __init__(self,
                 pot:int = 0,
                 gameRound:int = 0,
                 handList:list = [],
                 communityCardsList:list = []):
        """gameRound > 1 will pass ante stage"""
        self.pot = pot
        self.gameRound = gameRound
        self.handList  = handList
        self.communityCardsList = communityCardsList
        self.pokerList = list(POKER.keys())

    def holdme(self,choice = ANTE,money = 0):
        self.gameRound += 1 
        match self.gameRound:
            case 1:
                self.deal_player()
                self.pot += self.wager(choice)        
            case 2:
                self.deal_community(3)
                # self.pot += self.wager(choice,money)
            case 3:
                self.deal_community(1)
            case 4:            
                self.deal_community(1)
            case _:
                pass

        return self.pot

    # player operation
    def wager(self,wager,money = 0,ante = 10):
        totalBet = 0
        if   wager == ANTE:
            for i in range(len(play_chip)):
                play_chip[i] -= ante
                totalBet += ante
        elif wager == CALL:
            #bot oper
            pass
        elif wager == CHECK:
            pass
        elif wager == BET_RAISE:
            pass
        elif wager == FOLD:
            pass

        return totalBet

    def deal_player(self):
        if len(self.handList) == 5:
            return
        for i in range(5):
            # get 2 hand
            element = random.sample(self.pokerList,2)
            self.handList.append(element)
            for i in range(2):
                self.pokerList.remove(element[i])

    def deal_community(self,get:int):
        if len(self.communityCardsList) == 5:
            return 
        for i in range(get):
            element = random.choice(self.pokerList)
            self.communityCardsList.append(element)
            self.pokerList.remove(element)