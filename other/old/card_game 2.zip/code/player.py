
class Player:
    pass

class Bot(Player):
    pass