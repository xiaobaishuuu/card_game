from Card_game import *
from Holdem import *

game = Holdme()

press = False
choice = ANTE

def update_game():
    global press,choice
    draw_table()
    draw_players()
    #====================================================================
    # round 1
    if game.gameRound >= 1:
        draw_hand(game,press)
    # round 2
    if game.gameRound >= 2:
        draw_community(game,range(3),2)
    # round 3
    if game.gameRound >= 3:
        draw_community(game,range(3,4),3)
    # round 4
    if game.gameRound >= 4:
        draw_community(game,range(4,5),4)
    pot = game.holdme()
    # =====================================================================    
    choice = check_button(game.gameRound,press,pot/2)
    if choice == FOLD:
        press = True
    pygame.display.flip()

if __name__ == '__main__':
    while True:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()     
        update_game()   
        
    