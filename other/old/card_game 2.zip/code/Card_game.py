from init import *
from button import *

def draw_table():
    pygame.draw.rect(screen,TABLE_COLOR,TABLE_RECT,0,1000)
    pygame.draw.rect(screen,TABLE_PADDING_COLOR,TABLE_RECT,50,1000)
    pygame.draw.rect(screen,TABLE_BORDER_COLOR,TABLE_RECT,10,1000)
    for i in range(5):
        pygame.draw.rect(screen,POKER_PLACE_COLOR,(405+(GAP+POKER_WIDTH*POKER_TABLE_RATIO)*i,120,POKER_WIDTH*POKER_TABLE_RATIO,POKER_HEIGHT*POKER_TABLE_RATIO),3,5)

def draw_players():
    for i in range(len(PLAYER_INFO_BAR_LIST)):
        pygame.draw.rect(PLAYER_INFO_BAR_LIST[i],PLAYER_INFO_BAR_COLOR,(0,0,PLAYER_INFO_BAR_WIDTH,PLAYER_INFO_BAR_HEIGHT),0,20) 
        PLAYER_INFO_BAR_LIST[i].blit(PLAYER_NAME_FONT.render(f'User {i+1}',True,PLAYER_NAME_FONT_COLOR),(70,25))
        PLAYER_INFO_BAR_LIST[i].blit(PLAYER_NAME_FONT.render(f'$ {play_chip[i]}',True,PLAYER_NAME_FONT_COLOR),(70,55))
        PLAYER_INFO_BAR_LIST[i].blit(pygame.transform.scale_by(PLAYER_ICON,PLAYER_ICON_RATIO),(0,20))
        screen.blit(PLAYER_INFO_BAR_LIST[i],PLAYER_INFO_BAR_POSITION[i])

def draw_card(playerId:int,card_id:str,position:tuple,deal:bool = False,fold = False):
    '''playerId 1-5 == hand, -1 == community cards'''
    if deal:
        deal_animation(position)
    #player
    if playerId == 2 or playerId == -1:
        screen.blit(pygame.transform.smoothscale_by(POKER[card_id],POKER_RATIO),position)
        #fold
        if playerId == 2 and fold == True:
            pygame.draw.rect(FOLD_LAYER,(0,0,0,128),FOLD_LAYER.get_rect(),0,2)            
            screen.blit(FOLD_LAYER,position)
    #bot
    else:
        screen.blit(pygame.transform.smoothscale_by(CARD_BACK,POKER_RATIO),position)

def deal_animation(position:tuple,duration:int = 0.3):
    frame = screen.copy()
    start_time = time.time()
    while True:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
        # check animation time 
        progress = min((time.time() - start_time) / duration, 1.0)

        # change pos
        current_x = POKER_INITIAL_POSITION[0] + (position[0] - POKER_INITIAL_POSITION[0]) * progress
        current_y = POKER_INITIAL_POSITION[1] + (position[1] - POKER_INITIAL_POSITION[1]) * progress
        screen.blit(frame,(0,0))
        screen.blit(pygame.transform.smoothscale_by(CARD_BACK,POKER_RATIO),(current_x, current_y))
        pygame.display.flip()

        # end the animation
        if progress >= 1.0:
            break

def draw_hand(game,press):
    '''draw all hand card'''
    for i in range(len(PLAYER_INFO_BAR_LIST)):
        for j in range(2):
            if game.gameRound == 1:
                draw_card(i,game.handList[i][j],HAND_POSITION[i][j],True)
            draw_card(i,game.handList[i][j],HAND_POSITION[i][j],False,press)

def draw_community(game,deal_range:range,conditon_num:int):
    '''"deal_range" is the range of dealing card\n
    "conditon_num" is  which round will deal the card in animation'''
    for i in deal_range:
        if game.gameRound == conditon_num:
            draw_card(-1,game.communityCardsList[i],COMMUNITY_CARDS_POSITION[i],True)
        draw_card(-1,game.communityCardsList[i],COMMUNITY_CARDS_POSITION[i])

def check_button(gameRound = 0,press = False,least_bet = 0):
    '''press == True will pass,return button name'''
    choice = ''
    Button.init_raise(least_bet)
    while not press:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            # only check
            for button in buttonList:         
                #check all betting button
                if button.check(event):
                    choice = button.text
                    #either betting button press
                    if button.flag == 0:
                        press = True
                # first round cant fold
                if gameRound == 1:
                    break
        # only draw
        for button in buttonList:
            button.draw(screen)
            # first round cant fold
            if gameRound == 1:
                break
    bet = button.get_bet() if choice == BET_RAISE else least_bet
    print(choice,bet)
    return choice

if __name__ == '__main__':
    while True:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
