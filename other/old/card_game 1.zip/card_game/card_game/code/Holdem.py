from init import *

class Holdme:
    """    # only calculates"""

    def __init__(self,
                 pot:int = 0,
                 gameRound:int = 0,
                 handList:list = [],
                 communityCardsList:list = []):
        """gameRound > 1 will pass ante stage"""
        self.pot = pot
        self.gameRound = gameRound
        self.handList  = handList
        self.communityCardsList = communityCardsList
        self.pokerList = list(POKER.keys())

    def holdme(self,choice = ANTE):
        self.gameRound += 1
        if   self.gameRound == 1:            
            self.deal_player()
            self.pot += self.wager(choice)

        elif self.gameRound == 2:
            self.deal_community(3)
            self.wager(choice)

        elif self.gameRound == 3:
            self.deal_community(1)

        elif self.gameRound == 4:
            self.deal_community(1)
            
        else:
            pass
    # player operation
    def wager(self,wager,money = 0):
        totalBet = 0
        if   wager == ANTE:
            for i in range(len(play_chip)):
                play_chip[i] -= 10
                totalBet += 10
        elif wager == BET_CALL:
            pass
        elif wager == CHECK:
            pass
        elif wager == RAISE:
            pass
        elif wager == FOLD:
            pass

        return totalBet

    def deal_player(self):
        if len(self.handList) == 5:
            return
        for i in range(5):
            # get 2 hand
            element = random.sample(self.pokerList,2)
            self.handList.append(element)
            for i in range(2):
                self.pokerList.remove(element[i])

    def deal_community(self,get:int):
        if len(self.communityCardsList) == 5:
            return 
        for i in range(get):
            element = random.choice(self.pokerList)
            self.communityCardsList.append(element)
            self.pokerList.remove(element)