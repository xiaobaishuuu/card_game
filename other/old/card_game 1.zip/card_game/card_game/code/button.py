from init import *
import pygame
class Button:
    '''draw a button in a Surface'''
    def __init__(self,     
                 text:str,
                 rect:pygame.Rect,
                 color = BUTTON_COLOR,
                 touch_color = BUTTON_TOUCH_COLOR,
                 flag  = 0):
        """flag is button function, betting == 0,setting == 1"""
        self.text  = text
        self.rect  = rect
        self.color = color
        self.touch = touch_color
        self.flag  = flag

    def check(self, event):
        """return True when the button release"""
        # reset color in every loop
        self.color = BUTTON_COLOR
        self.touch = BUTTON_TOUCH_COLOR
        # mouse out of screen will lead to attr errer (null event.pos) 
        try:
            if self.rect.collidepoint(event.pos):
                self.touch = BUTTON_ACTIVE_TOUCH_COLOR
                # press
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.color = BUTTON_ACTIVE_COLOR
                    self.draw(screen)
                # release
                elif event.type == pygame.MOUSEBUTTONUP:
                    self.color = BUTTON_COLOR
                    self.touch = BUTTON_TOUCH_COLOR
                    return True
        except AttributeError:
            pass
        return False

    def draw(self, screen:pygame.Surface):
        """draw the button"""
        pygame.draw.rect(screen,self.color, self.rect,0,25)
        pygame.draw.rect(screen,self.touch, self.rect,10,25)
        pygame.draw.rect(screen,self.color, self.rect,5,25)
        text = BUTTON_FONT.render(self.text,True,BUTTON_FONT_COLOR)
        screen.blit(text,((self.rect.x + self.rect.width/2) - text.get_width()/2,self.rect.y + 30))
        pygame.display.flip()

__betButton_y = PLAYER_INFO_BAR_POSITION[2][1]+(PLAYER_INFO_BAR_HEIGHT/2)-BUTTON_HEIGHT/2
__betButton_x = PLAYER_INFO_BAR_POSITION[2][0]

buttonList = [Button(CHECK   ,pygame.Rect(__betButton_x - (BUTTON_GAP + BUTTON_WIDTH)*2,__betButton_y,BUTTON_WIDTH,BUTTON_HEIGHT)),
              Button(FOLD    ,pygame.Rect(__betButton_x - (BUTTON_GAP + BUTTON_WIDTH)*3,__betButton_y,BUTTON_WIDTH,BUTTON_HEIGHT)),
              Button(BET_CALL,pygame.Rect(__betButton_x - (BUTTON_GAP + BUTTON_WIDTH)  ,__betButton_y,BUTTON_WIDTH,BUTTON_HEIGHT)),
              Button(RAISE   ,pygame.Rect(__betButton_x + PLAYER_INFO_BAR_WIDTH + BUTTON_GAP + BUTTON_WIDTH ,__betButton_y,BUTTON_WIDTH,BUTTON_HEIGHT)),
              Button(UP      ,pygame.Rect(__betButton_x + PLAYER_INFO_BAR_WIDTH + BUTTON_WIDTH ,__betButton_y,BUTTON_WIDTH,BUTTON_HEIGHT)),
              Button(DOWN    ,pygame.Rect(__betButton_x + PLAYER_INFO_BAR_WIDTH + BUTTON_WIDTH + BUTTON_GAP + BUTTON_WIDTH,__betButton_y,BUTTON_WIDTH,BUTTON_HEIGHT))]