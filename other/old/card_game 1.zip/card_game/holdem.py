import pygame
import os.path
pygame.init()

SCREEN_WIDTH = 1280
SCREEN_HEIGHT= 720
SCREEN_COLOR = (242, 225, 231)
screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
pygame.display.set_caption('Card Game')

# Center position: screen size - (gap * 2)
TABLE_HEIGHT= 580
TABLE_WIDTH = 1000
TABLE_COLOR = (17, 113, 61)
TABLE_RECT  = pygame.Rect(140,70,TABLE_WIDTH,TABLE_HEIGHT)

POKER_WIDTH = 500
POKER_HEIGHT= 726
POKER_RATIO =  0.13
POKER_TABLE_RATIO = 0.18 #NO CHANGE

def load_image():
    Userimage = pygame.image.load(f'{os.path.dirname(__file__)}\\User.jpg').convert()

def draw_table():
    pygame.draw.rect(screen,TABLE_COLOR,TABLE_RECT,0,1000)
    for i in range(5):
        # Poker position: 405 + gap=5 + (POKER_WIDTH*POKER_TABLE_RATIO) * n
        pygame.draw.rect(screen,(204, 204, 204),(405+(5+POKER_WIDTH*POKER_TABLE_RATIO)*i,160,POKER_WIDTH*POKER_TABLE_RATIO,POKER_HEIGHT*POKER_TABLE_RATIO),3,5)

def update_game():
    screen.fill(SCREEN_COLOR)
    draw_table()
    pygame.display.flip()

def holdme():
    poker = pygame.transform.scale()

load_image()
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    update_game()
    
    
    

